// Function to add a new recommendation
function addRecommendation() {
  var input = document.getElementById("recommendation_input");
  var text = input.value.trim();

  if (text !== "") {
    // Create a new recommendation element
    var newRec = document.createElement("div");
    newRec.className = "recommendation";
    var p = document.createElement("p");
    p.textContent = '"' + text + '"';
    newRec.appendChild(p);

    // Append the new recommendation to the existing list
    document.getElementById("recommendations_list").appendChild(newRec);

    // Clear the input field
    input.value = "";

    // Show confirmation popup
    showPopup(true);
  }
}

// Function to display the popup confirmation
function showPopup(flag) {
  var popup = document.getElementById("popup");
  if (flag) {
    popup.style.display = "block";
    // Hide the popup after 3 seconds
    setTimeout(function() {
      popup.style.display = "none";
    }, 3000);
  }
}
